"""
DSA Explorer and Visualiser
Main entry point - launches menu and routes to modules.
"""

import pygame
import sys
from modules.data_structures import DataStructuresModule
from modules.sorting import SortingModule
from modules.graphs import GraphsModule
from modules.heap import HeapModule
from modules.puzzles import PuzzlesModule

# ── Constants ────────────────────────────────────────────────────────────────
WIDTH, HEIGHT = 1400, 900
FPS = 60

# Colour palette (Names kept same for compatibility, but values are LIGHT theme)
BG_DARK    = (255, 255, 255) # Now pure white
ACCENT     = (0, 102, 204)   # Deep Blue
ACCENT2    = (0, 51, 102)    # Darker Navy
TEXT_LIGHT = (20,  20,  20)  # Now almost black for readability
TEXT_DIM   = (100, 100, 100) # Slate Grey
PANEL      = (240, 240, 240) # Light Grey
BTN_HOVER  = (235, 245, 255) # Very light blue hover
BTN_NORMAL = (255, 255, 255) # White button
BTN_BORDER = (180, 200, 230) # Soft blue-grey border


def draw_gradient_bg(surface):
    """Draw a subtle vertical gradient background (White to Ice Blue)."""
    for y in range(HEIGHT):
        ratio = y / HEIGHT
        r = int(255 - ratio * 15)
        g = int(255 - ratio * 5)
        b = 255
        pygame.draw.line(surface, (r, g, b), (0, y), (WIDTH, y))


def draw_grid(surface):
    """Draw decorative dot-grid."""
    for x in range(0, WIDTH, 40):
        for y in range(0, HEIGHT, 40):
            pygame.draw.circle(surface, (230, 235, 245), (x, y), 1)


class MainMenu:
    MODULES = [
        ("Data Structures",  "Stack · Queue · Linked List · BST",        DataStructuresModule),
        ("Sorting",          "Bubble · Selection · Merge Sort",           SortingModule),
        ("Graph Traversal",  "BFS · DFS on Interactive Graph",            GraphsModule),
        ("Heap Visualiser",  "Min-Heap Insert & Extract",                 HeapModule),
        ("Puzzle Challenges","Pathfinding · Event Queue · DP Grid",       PuzzlesModule),
    ]

    def __init__(self, screen, fonts):
        self.screen = screen
        self.fonts  = fonts
        self.hovered = -1
        self.cards   = []
        self._build_cards()

    def _build_cards(self):
        card_w, card_h = 800, 72
        start_y = 200
        cx = (WIDTH - card_w) // 2
        for i, _ in enumerate(self.MODULES):
            rect = pygame.Rect(cx, start_y + i * (card_h + 14), card_w, card_h)
            self.cards.append(rect)

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hovered = -1
            for i, r in enumerate(self.cards):
                if r.collidepoint(event.pos):
                    self.hovered = i
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, r in enumerate(self.cards):
                if r.collidepoint(event.pos):
                    return i   # index of chosen module
        return None

    def draw(self, tick):
        draw_gradient_bg(self.screen)
        draw_grid(self.screen)

        # Title
        pulse = abs((tick % 120) - 60) / 60          # 0→1→0
        title_col = (
            min(255, int(ACCENT[0] + pulse * 30)),
            min(255, int(ACCENT[1] + pulse * 30)),
            min(255, int(ACCENT[2] + pulse * 30)),
        )
        title = self.fonts["title"].render("DSA Explorer", True, title_col)
        self.screen.blit(title, title.get_rect(center=(WIDTH // 2, 95)))

        sub = self.fonts["body"].render(
            "Data Structures & Algorithms — Interactive Visualiser", True, TEXT_DIM)
        self.screen.blit(sub, sub.get_rect(center=(WIDTH // 2, 145)))

        # Cards
        for i, (name, desc, _) in enumerate(self.MODULES):
            rect  = self.cards[i]
            hover = (i == self.hovered)

            # Shadow
            shadow = rect.move(4, 4)
            pygame.draw.rect(self.screen, (220, 225, 235), shadow, border_radius=14)

            # Card body
            col = BTN_HOVER if hover else BTN_NORMAL
            pygame.draw.rect(self.screen, col, rect, border_radius=14)
            border_col = ACCENT if hover else BTN_BORDER
            pygame.draw.rect(self.screen, border_col, rect, 2, border_radius=14)

            # Number badge
            badge_r = pygame.Rect(rect.x + 18, rect.y + rect.h // 2 - 18, 36, 36)
            pygame.draw.rect(self.screen, ACCENT if hover else (225, 235, 250),
                             badge_r, border_radius=8)
            num = self.fonts["small"].render(str(i + 1), True,
                                             (255, 255, 255) if hover else ACCENT)
            self.screen.blit(num, num.get_rect(center=badge_r.center))

            # Text
            lbl = self.fonts["card"].render(name, True,
                                            TEXT_LIGHT if hover else (40, 40, 40))
            self.screen.blit(lbl, (rect.x + 72, rect.y + 12))
            dsc = self.fonts["small"].render(desc, True, TEXT_DIM)
            self.screen.blit(dsc, (rect.x + 74, rect.y + 42))

            # Arrow
            if hover:
                arr = self.fonts["card"].render("→", True, ACCENT)
                self.screen.blit(arr, arr.get_rect(
                    midright=(rect.right - 20, rect.centery)))

        # Footer
        foot = self.fonts["small"].render(
            "Click a module to begin  •  ESC inside module to return", True, (130, 140, 150))
        self.screen.blit(foot, foot.get_rect(center=(WIDTH // 2, HEIGHT - 28)))


def make_fonts():
    pygame.font.init()
    try:
        title = pygame.font.SysFont("couriernew",   52, bold=True)
        card  = pygame.font.SysFont("couriernew",   22, bold=True)
        body  = pygame.font.SysFont("couriernew",   18)
        small = pygame.font.SysFont("couriernew",   15)
    except Exception:
        title = pygame.font.SysFont(None, 52, bold=True)
        card  = pygame.font.SysFont(None, 22, bold=True)
        body  = pygame.font.SysFont(None, 18)
        small = pygame.font.SysFont(None, 15)
    return {"title": title, "card": card, "body": body, "small": small}


def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("DSA Explorer and Visualiser")
    clock  = pygame.time.Clock()
    fonts  = make_fonts()
    menu   = MainMenu(screen, fonts)
    tick   = 0

    modules = [cls(screen, fonts) for _, _, cls in MainMenu.MODULES]
    active  = None   # index into modules list

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()

            if active is None:
                chosen = menu.handle_event(event)
                if chosen is not None:
                    active = chosen
                    modules[active].reset()
            else:
                result = modules[active].handle_event(event)
                if result == "menu":
                    active = None

        if active is None:
            menu.draw(tick)
        else:
            modules[active].update()
            modules[active].draw()

        pygame.display.flip()
        tick += 1
        clock.tick(FPS)


if __name__ == "__main__":
    main()