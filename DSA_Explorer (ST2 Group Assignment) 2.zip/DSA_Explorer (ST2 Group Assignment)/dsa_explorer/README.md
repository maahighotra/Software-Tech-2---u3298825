# DSA Explorer and Visualiser

Interactive Data Structures & Algorithms visualiser built with **Python + Pygame**.

## Setup

```bash
pip install pygame
```

## Run the App

```bash
cd dsa_explorer
python main.py
```

## Run Tests

```bash
cd dsa_explorer
python -m pytest tests/test_dsa.py -v
# or
python tests/test_dsa.py
```

---

## Project Structure

```
dsa_explorer/
├── main.py                  # Main menu + launcher
├── modules/
│   ├── __init__.py          # BaseModule + shared colours
│   ├── data_structures.py   # Phase 1 – Stack, Queue, Linked List, BST
│   ├── sorting.py           # Phase 2 – Bubble, Selection, Merge Sort
│   ├── graphs.py            # Phase 2 – BFS, DFS
│   ├── heap.py              # Phase 2 – Min-Heap
│   └── puzzles.py           # Phase 3 – A*, Event Queue, DP Grid
└── tests/
    └── test_dsa.py          # Automated unit tests (all 3 phases)
```

---

## Features by Phase

### Phase 1 – Data Structures Playground
| Structure | Operations |
|-----------|-----------|
| Stack | Push, Pop, Peek, Clear — animated boxes |
| Queue | Enqueue, Dequeue, Clear — horizontal FIFO display |
| Linked List | Insert head/tail, Delete head, Reverse, Clear |
| BST | Insert, Inorder / Preorder / Postorder traversal |

### Phase 2 – Algorithm Visualiser
| Algorithm | Features |
|-----------|---------|
| Bubble Sort | Step-by-step bars, compare/swap highlights, progress bar |
| Selection Sort | Same animated framework, min-tracking colour |
| Merge Sort | Subarray range highlight, iterative merge |
| BFS | Click any node as start, level-order animation |
| DFS | Click any node as start, stack-based animation |
| Min-Heap | Animated sift-up (insert) and sift-down (extract) |

### Phase 3 – Puzzle Challenges
| Puzzle | Description |
|--------|-------------|
| Pathfinding (A*) | Draw walls, set start/end, watch A* find the shortest path |
| Event Queue Sim | Add random events, process in priority order, view log |
| DP Grid | Toggle obstacles, compute path counts, reconstruct one path |

---

## Controls
- **ESC** — return to main menu from any module
- **Mouse click** — interact with data structures, set nodes, draw walls
- **Mouse drag** — draw walls in Pathfinding puzzle
- All buttons are on-screen; no keyboard shortcuts required for core features.

---

## Automated Tests

Tests cover:
- **Module 1**: Stack push/pop, Queue FIFO, LinkedList insert/delete/reverse, BST traversals
- **Module 2**: Bubble/Selection/Merge sort correctness, BFS/DFS order, MinHeap ordering
- **Module 3**: A* path found/blocked, DP path counting with obstacles, EventSim priority ordering
