"""
Phase 2 – Heap Visualiser
Min-Heap: insert and extract-min with animated step-by-step display.
"""

import pygame
import math
from modules import BaseModule, WIDTH, HEIGHT
from modules import (ACCENT, ACCENT2, TEXT_LIGHT, TEXT_DIM,
                     RED, GREEN, YELLOW, BG_DARK)

NODE_R = 28
STEP_DELAY = 30


class MinHeap:
    """Pure min-heap implementation (used by unit tests too)."""

    def __init__(self):
        self._data = []

    def insert(self, val):
        self._data.append(val)
        self._sift_up(len(self._data) - 1)

    def extract_min(self):
        if not self._data:
            return None
        if len(self._data) == 1:
            return self._data.pop()
        root = self._data[0]
        self._data[0] = self._data.pop()
        self._sift_down(0)
        return root

    def peek(self):
        return self._data[0] if self._data else None

    def _sift_up(self, i):
        while i > 0:
            parent = (i - 1) // 2
            if self._data[parent] > self._data[i]:
                self._data[parent], self._data[i] = self._data[i], self._data[parent]
                i = parent
            else:
                break

    def _sift_down(self, i):
        n = len(self._data)
        while True:
            smallest = i
            l, r     = 2*i+1, 2*i+2
            if l < n and self._data[l] < self._data[smallest]:
                smallest = l
            if r < n and self._data[r] < self._data[smallest]:
                smallest = r
            if smallest != i:
                self._data[smallest], self._data[i] = self._data[i], self._data[smallest]
                i = smallest
            else:
                break

    def items(self):
        return list(self._data)


def insert_steps(heap_items, val):
    """Yield (snapshot, highlight_pair) for insert animation."""
    data = list(heap_items) + [val]
    i = len(data) - 1
    yield list(data), (i, i)
    while i > 0:
        p = (i - 1) // 2
        yield list(data), (i, p)
        if data[p] > data[i]:
            data[p], data[i] = data[i], data[p]
            i = p
            yield list(data), (i, i)
        else:
            break
    yield list(data), None


def extract_steps(heap_items):
    """Yield (snapshot, highlight_pair) for extract-min animation."""
    if not heap_items:
        return
    data = list(heap_items)
    yield list(data), (0, 0)                    # show root
    if len(data) == 1:
        yield [], None
        return
    data[0] = data.pop()
    n = len(data)
    yield list(data), (0, 0)
    i = 0
    while True:
        smallest = i
        l, r = 2*i+1, 2*i+2
        if l < n and data[l] < data[smallest]:
            smallest = l
        if r < n and data[r] < data[smallest]:
            smallest = r
        yield list(data), (i, smallest)
        if smallest != i:
            data[i], data[smallest] = data[smallest], data[i]
            i = smallest
            yield list(data), (i, i)
        else:
            break
    yield list(data), None


def node_positions(n):
    """Compute (x, y) for each index in a heap array using tree layout."""
    positions = {}
    if n == 0:
        return positions
    level_y_start = 160
    level_h       = 90

    level = 0
    start = 0
    while start < n:
        count    = min(2**level, n - start)
        level_y  = level_y_start + level * level_h
        span_w   = WIDTH - 200
        step     = span_w / (2**level + 1)
        offset   = (WIDTH - 200) // 2 + 100 - step * (2**level) // 2
        for j in range(count):
            idx = start + j
            x   = int(offset + step * (j + 0.5) + step / 2)
            positions[idx] = (x, level_y)
        start += count
        level += 1
    return positions


class HeapModule(BaseModule):
    title = "Heap Visualiser — Min-Heap · Insert · Extract"

    def reset(self):
        self.heap      = MinHeap()
        self.anim_steps = []
        self.anim_idx   = 0
        self.anim_data  = []
        self.anim_hl    = None
        self.playing    = False
        self.tick       = 0
        self._next      = 1
        self.last_extracted = None
        self.message    = "Insert values into the min-heap."
        self.buttons    = []
        self._build_buttons()

    def _build_buttons(self):
        self.buttons = []
        self._make_button(20,  52, 120, 30, "Insert",      self._insert)
        self._make_button(150, 52, 150, 30, "Extract Min", self._extract)
        self._make_button(310, 52, 90,  30, "Clear",       self._clear)

    def _next_val(self):
        import random
        return random.randint(1, 99)

    def _insert(self):
        if self.playing:
            return
        v = self._next_val()
        self.anim_steps = list(insert_steps(self.heap.items(), v))
        self.anim_idx   = 0
        self.playing    = True
        self.message    = f"Inserting {v}…"
        # Actually insert into heap so data is consistent after anim
        self._pending_val = v

    def _extract(self):
        if self.playing or not self.heap.items():
            return
        self.anim_steps = list(extract_steps(self.heap.items()))
        self.anim_idx   = 0
        self.playing    = True
        self.last_extracted = self.heap.peek()
        self.message    = f"Extracting min ({self.last_extracted})…"

    def _clear(self):
        self.heap = MinHeap()
        self.anim_steps = []
        self.anim_data  = []
        self.anim_hl    = None
        self.playing    = False
        self.last_extracted = None
        self.message    = "Heap cleared."

    def handle_event(self, event):
        return super().handle_event(event)

    def update(self):
        if not self.playing:
            return
        self.tick += 1
        if self.tick % STEP_DELAY == 0:
            if self.anim_idx < len(self.anim_steps):
                snap, hl = self.anim_steps[self.anim_idx]
                self.anim_data = snap
                self.anim_hl   = hl
                self.anim_idx += 1
            else:
                # Commit changes to real heap
                if hasattr(self, '_pending_val'):
                    self.heap.insert(self._pending_val)
                    del self._pending_val
                    self.message = "Insert complete."
                else:
                    self.heap.extract_min()
                    self.message = f"Extracted {self.last_extracted}. New min: {self.heap.peek()}"
                self.anim_data = self.heap.items()
                self.anim_hl   = None
                self.playing   = False

    def draw(self):
        super().draw()

        data      = self.anim_data if self.playing else self.heap.items()
        positions = node_positions(len(data))

        # Draw edges
        for i in range(len(data)):
            l, r = 2*i+1, 2*i+2
            if l < len(data):
                pygame.draw.line(self.screen, (50, 80, 150),
                                 positions[i], positions[l], 2)
            if r < len(data):
                pygame.draw.line(self.screen, (50, 80, 150),
                                 positions[i], positions[r], 2)

        # Draw nodes
        for i, val in enumerate(data):
            cx, cy = positions[i]
            hl     = self.anim_hl and i in self.anim_hl
            fill   = YELLOW if hl else (30, 55, 110)
            border = RED    if hl else ACCENT
            pygame.draw.circle(self.screen, fill,   (cx, cy), NODE_R)
            pygame.draw.circle(self.screen, border, (cx, cy), NODE_R, 2)
            lbl = self.fonts["small"].render(str(val), True,
                                             BG_DARK if hl else TEXT_LIGHT)
            self.screen.blit(lbl, lbl.get_rect(center=(cx, cy)))

        # Array representation at bottom
        arr_y = HEIGHT - 80
        arr_x = 30
        arr_lbl = self.fonts["small"].render("Array: ", True, TEXT_DIM)
        self.screen.blit(arr_lbl, (arr_x, arr_y))
        for i, v in enumerate(data):
            box = pygame.Rect(arr_x + 60 + i * 46, arr_y - 2, 42, 24)
            pygame.draw.rect(self.screen, (25, 45, 90), box, border_radius=4)
            pygame.draw.rect(self.screen, (60, 100, 160), box, 1, border_radius=4)
            vl = self.fonts["small"].render(str(v), True, TEXT_LIGHT)
            self.screen.blit(vl, vl.get_rect(center=box.center))

        self._draw_message(self.message, HEIGHT - 22, ACCENT2)
