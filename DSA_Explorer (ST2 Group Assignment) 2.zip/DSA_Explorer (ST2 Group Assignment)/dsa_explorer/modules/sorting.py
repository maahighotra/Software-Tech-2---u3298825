"""
Phase 2 – Sorting Module
Visualises: Bubble Sort, Selection Sort, Merge Sort (animated step-by-step)
"""

import pygame
import random
from modules import BaseModule, WIDTH, HEIGHT
from modules import (ACCENT, ACCENT2, TEXT_LIGHT, TEXT_DIM,
                     RED, GREEN, YELLOW, BLUE, BG_DARK)

BAR_MAX_H = 360
ARRAY_SIZE = 20
STEP_DELAY = 8   # frames between auto-steps


def bubble_sort_steps(arr):
    """Yield (array_snapshot, compare_indices, swap_indices) for each step."""
    a = arr[:]
    n = len(a)
    for i in range(n):
        for j in range(0, n - i - 1):
            yield list(a), (j, j + 1), None
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                yield list(a), None, (j, j + 1)
    yield list(a), None, None


def selection_sort_steps(arr):
    a = arr[:]
    n = len(a)
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            yield list(a), (min_idx, j), None
            if a[j] < a[min_idx]:
                min_idx = j
        if min_idx != i:
            a[i], a[min_idx] = a[min_idx], a[i]
            yield list(a), None, (i, min_idx)
    yield list(a), None, None


def merge_sort_steps(arr):
    """Iterative merge sort that yields (array_snapshot, highlight_range)."""
    a  = arr[:]
    n  = len(a)
    size = 1
    while size < n:
        for lo in range(0, n, size * 2):
            mid  = min(lo + size,     n)
            hi   = min(lo + size * 2, n)
            left = a[lo:mid]
            rght = a[mid:hi]
            i = j = 0
            k = lo
            while i < len(left) and j < len(rght):
                yield list(a), (lo, hi), None
                if left[i] <= rght[j]:
                    a[k] = left[i]; i += 1
                else:
                    a[k] = rght[j]; j += 1
                k += 1
            while i < len(left):
                a[k] = left[i]; i += 1; k += 1
            while j < len(rght):
                a[k] = rght[j]; j += 1; k += 1
            yield list(a), (lo, hi), None
        size *= 2
    yield list(a), None, None


ALGORITHMS = {
    "Bubble Sort":    bubble_sort_steps,
    "Selection Sort": selection_sort_steps,
    "Merge Sort":     merge_sort_steps,
}


class SortingModule(BaseModule):
    title = "Sorting Algorithms — Bubble · Selection · Merge"

    def reset(self):
        self.algo_name  = "Bubble Sort"
        self.array      = [random.randint(5, 100) for _ in range(ARRAY_SIZE)]
        self.steps      = []
        self.step_index = 0
        self.playing    = False
        self.done       = False
        self.compare    = None
        self.swap       = None
        self.hl_range   = None
        self.tick       = 0
        self.message    = "Choose an algorithm and press Start."
        self.buttons    = []
        self._build_buttons()

    def _build_buttons(self):
        self.buttons = []
        # Algorithm selector tabs
        for i, name in enumerate(ALGORITHMS):
            self._make_button(20 + i * 200, 52, 190, 30, name,
                              lambda n=name: self._set_algo(n))
        # Control buttons
        self._make_button(700, 52, 90,  30, "Shuffle",   self._shuffle)
        self._make_button(795, 52, 90,  30, "Start",     self._start)
        self._make_button(700, 88, 90,  30, "Step",      self._do_step)
        self._make_button(795, 88, 90,  30, "Reset",     self._reset_sort)

    def _set_algo(self, name):
        self.algo_name = name
        self._reset_sort()
        self.message = f"{name} selected."

    def _shuffle(self):
        self.array = [random.randint(5, 100) for _ in range(ARRAY_SIZE)]
        self._reset_sort()
        self.message = "Array shuffled."

    def _start(self):
        if self.done:
            self._shuffle()
        self.steps      = list(ALGORITHMS[self.algo_name](self.array))
        self.step_index = 0
        self.playing    = True
        self.done       = False
        self.message    = f"Running {self.algo_name}…"

    def _reset_sort(self):
        self.steps      = []
        self.step_index = 0
        self.playing    = False
        self.done       = False
        self.compare    = None
        self.swap       = None
        self.hl_range   = None

    def _do_step(self):
        if not self.steps:
            self.steps = list(ALGORITHMS[self.algo_name](self.array))
        if self.step_index < len(self.steps):
            self._apply_step(self.steps[self.step_index])
            self.step_index += 1

    def _apply_step(self, step):
        arr_snap, comp, swap = step
        self.array   = arr_snap
        self.compare = comp
        self.swap    = swap
        self.hl_range = comp  # re-use for merge sort range

    def handle_event(self, event):
        return super().handle_event(event)

    def update(self):
        if not self.playing or self.done:
            return
        self.tick += 1
        if self.tick % STEP_DELAY == 0:
            if self.step_index < len(self.steps):
                self._apply_step(self.steps[self.step_index])
                self.step_index += 1
            else:
                self.playing = False
                self.done    = True
                self.compare = None
                self.swap    = None
                self.message = f"{self.algo_name} complete! ✓"

    def draw(self):
        super().draw()

        # highlight selected algo tab
        for i, name in enumerate(ALGORITHMS):
            rect = self.buttons[i][0]
            if name == self.algo_name:
                pygame.draw.rect(self.screen, ACCENT, rect, border_radius=8)
                lbl = self.fonts["small"].render(name, True, BG_DARK)
                self.screen.blit(lbl, lbl.get_rect(center=rect.center))

        # draw bars
        area    = pygame.Rect(10, 155, WIDTH - 20, HEIGHT - 200)
        bar_w   = area.width // len(self.array)
        max_val = max(self.array) if self.array else 1

        for i, v in enumerate(self.array):
            bar_h = int(v / max_val * BAR_MAX_H)
            x     = area.left + i * bar_w + 2
            y     = area.bottom - bar_h

            if self.swap and i in self.swap:
                color = RED
            elif self.compare and i in self.compare:
                color = YELLOW
            elif self.hl_range and isinstance(self.hl_range, tuple):
                lo, hi = self.hl_range
                color  = BLUE if lo <= i < hi else (50, 90, 160)
            else:
                color = (50, 90, 160)

            pygame.draw.rect(self.screen, color,
                             (x, y, bar_w - 4, bar_h), border_radius=3)

        # progress bar
        if self.steps:
            prog = self.step_index / len(self.steps)
            pygame.draw.rect(self.screen, (30, 50, 90),
                             (10, HEIGHT - 42, WIDTH - 20, 8), border_radius=4)
            pygame.draw.rect(self.screen, ACCENT,
                             (10, HEIGHT - 42, int((WIDTH - 20) * prog), 8),
                             border_radius=4)

        # Legend
        for col, label, off in [(YELLOW, "Comparing", 0),
                                  (RED,    "Swapping",  200),
                                  (BLUE,   "Subarray",  380)]:
            pygame.draw.rect(self.screen, col,
                             (area.left + 10 + off, area.top + 8, 14, 14))
            lbl = self.fonts["small"].render(label, True, TEXT_DIM)
            self.screen.blit(lbl, (area.left + 28 + off, area.top + 8))

        self._draw_message(self.message, HEIGHT - 22, ACCENT2)
