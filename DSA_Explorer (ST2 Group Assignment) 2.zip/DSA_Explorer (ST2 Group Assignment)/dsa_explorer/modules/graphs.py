"""
Phase 2 – Graph Traversal Module
BFS and DFS with interactive node selection.
"""

import pygame
import math
from collections import deque
from modules import BaseModule, WIDTH, HEIGHT
from modules import (ACCENT, ACCENT2, TEXT_LIGHT, TEXT_DIM,
                     RED, GREEN, YELLOW, BLUE, BG_DARK, ORANGE)

NODE_R = 28
STEP_DELAY = 22   # frames between traversal steps

# Fixed graph layout (node: (x, y))
NODES = {
    'A': (180, 200), 'B': (340, 140), 'C': (500, 200),
    'D': (260, 320), 'E': (420, 340), 'F': (600, 320),
    'G': (340, 470), 'H': (560, 470),
}
EDGES = [
    ('A','B'), ('A','D'),
    ('B','C'), ('B','E'),
    ('C','F'),
    ('D','E'), ('D','G'),
    ('E','F'), ('E','G'),
    ('F','H'),
    ('G','H'),
]


def build_adj(nodes, edges):
    adj = {n: [] for n in nodes}
    for u, v in edges:
        adj[u].append(v)
        adj[v].append(u)
    return adj


def bfs_steps(adj, start):
    visited = set()
    queue   = deque([start])
    visited.add(start)
    order   = []
    while queue:
        node = queue.popleft()
        order.append(node)
        yield list(order), node
        for nb in sorted(adj[node]):
            if nb not in visited:
                visited.add(nb)
                queue.append(nb)


def dfs_steps(adj, start):
    visited = set()
    stack   = [start]
    order   = []
    while stack:
        node = stack.pop()
        if node in visited:
            continue
        visited.add(node)
        order.append(node)
        yield list(order), node
        for nb in sorted(adj[node], reverse=True):
            if nb not in visited:
                stack.append(nb)


class GraphsModule(BaseModule):
    title = "Graph Traversal — BFS · DFS"

    def reset(self):
        self.adj        = build_adj(NODES, EDGES)
        self.algo       = "BFS"
        self.start_node = "A"
        self.visited    = []
        self.current    = None
        self.steps_gen  = None
        self.playing    = False
        self.done       = False
        self.tick       = 0
        self.order_log  = []
        self.message    = "Click a node to set start, then press Start."
        self.buttons    = []
        self._build_buttons()

    def _build_buttons(self):
        self.buttons = []
        self._make_button(20,  52, 120, 30, "BFS",   lambda: self._set_algo("BFS"))
        self._make_button(150, 52, 120, 30, "DFS",   lambda: self._set_algo("DFS"))
        self._make_button(310, 52, 100, 30, "Start", self._start)
        self._make_button(420, 52, 100, 30, "Step",  self._do_step)
        self._make_button(530, 52, 100, 30, "Reset", self._reset_trav)

    def _set_algo(self, name):
        self.algo = name
        self._reset_trav()
        self.message = f"{name} selected. Click a start node."

    def _start(self):
        self._reset_trav()
        fn = bfs_steps if self.algo == "BFS" else dfs_steps
        self.steps_gen = fn(self.adj, self.start_node)
        self.playing   = True
        self.message   = f"{self.algo} from '{self.start_node}' running…"

    def _reset_trav(self):
        self.visited   = []
        self.current   = None
        self.steps_gen = None
        self.playing   = False
        self.done      = False
        self.order_log = []

    def _do_step(self):
        if self.steps_gen is None:
            self._start()
        self._advance()

    def _advance(self):
        if self.steps_gen is None:
            return
        try:
            order, cur = next(self.steps_gen)
            self.visited  = order
            self.current  = cur
            self.order_log = order
        except StopIteration:
            self.playing = False
            self.done    = True
            self.current = None
            self.message = f"{self.algo} complete! Order: {self.order_log}"

    def handle_event(self, event):
        result = super().handle_event(event)
        if result:
            return result
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # Check if clicked on a node
            for name, (nx, ny) in NODES.items():
                dx = event.pos[0] - nx
                dy = event.pos[1] - ny
                if dx*dx + dy*dy <= NODE_R * NODE_R:
                    self.start_node = name
                    self._reset_trav()
                    self.message = f"Start node set to '{name}'. Press Start."
                    break
        return None

    def update(self):
        if not self.playing or self.done:
            return
        self.tick += 1
        if self.tick % STEP_DELAY == 0:
            self._advance()

    def draw(self):
        super().draw()

        # Algo tabs
        for label in ("BFS", "DFS"):
            for rect, btn_lbl, _ in self.buttons:
                if btn_lbl == label:
                    if self.algo == label:
                        pygame.draw.rect(self.screen, ACCENT, rect, border_radius=8)
                        lbl = self.fonts["small"].render(label, True, BG_DARK)
                        self.screen.blit(lbl, lbl.get_rect(center=rect.center))

        # Edges
        for u, v in EDGES:
            x1, y1 = NODES[u]
            x2, y2 = NODES[v]
            both_visited = u in self.visited and v in self.visited
            col = ACCENT if both_visited else (50, 70, 110)
            w   = 3 if both_visited else 1
            pygame.draw.line(self.screen, col, (x1, y1), (x2, y2), w)

        # Nodes
        for name, (nx, ny) in NODES.items():
            if name == self.current:
                fill   = YELLOW
                border = ORANGE
            elif name in self.visited:
                fill   = GREEN
                border = ACCENT
            elif name == self.start_node:
                fill   = BLUE
                border = ACCENT
            else:
                fill   = (30, 55, 110)
                border = (80, 120, 200)

            pygame.draw.circle(self.screen, fill,   (nx, ny), NODE_R)
            pygame.draw.circle(self.screen, border, (nx, ny), NODE_R, 2)
            lbl = self.fonts["body"].render(name, True, BG_DARK)
            self.screen.blit(lbl, lbl.get_rect(center=(nx, ny)))

        # Order log
        if self.order_log:
            log_str = " → ".join(self.order_log)
            log = self.fonts["small"].render(f"Order: {log_str}", True, ACCENT2)
            self.screen.blit(log, (680, 200))

        # Legend
        for col, label, yoff in [(BLUE, "Start", 0), (YELLOW, "Current", 25),
                                   (GREEN, "Visited", 50)]:
            pygame.draw.circle(self.screen, col, (690, 320 + yoff), 8)
            lbl = self.fonts["small"].render(label, True, TEXT_DIM)
            self.screen.blit(lbl, (706, 314 + yoff))

        self._draw_message(self.message, HEIGHT - 22, ACCENT2)
