"""
Phase 3 – Puzzle Challenges
1. Pathfinding Puzzle  – A* on user-drawn grid
2. Event Queue Sim     – Priority-queue heap scheduler
3. DP Grid Puzzle      – Path counting with obstacles
"""

import pygame
import heapq
from modules import BaseModule, WIDTH, HEIGHT
from modules import (ACCENT, ACCENT2, ACCENT3, TEXT_LIGHT, TEXT_DIM,
                     RED, GREEN, YELLOW, BLUE, BG_DARK, ORANGE, PURPLE)

# ── shared colours ────────────────────────────────────────────────────────────
WALL_COL   = (40,  50,  80)
OPEN_COL   = (20,  32,  60)
PATH_COL   = (255, 200,  50)
START_COL  = (60,  220, 100)
END_COL    = (255,  80,  80)
VISIT_COL  = (30, 100, 200)
GRID_LINE  = (30,  45,  80)

TABS = ["Pathfinding (A*)", "Event Queue", "DP Grid"]

# ══════════════════════════════════════════════════════════════════════════════
# A* Pathfinding — returns ordered visited list + ordered path list
# ══════════════════════════════════════════════════════════════════════════════

ROWS, COLS = 16, 22
CELL = 30   # px

def heuristic(a, b):
    return abs(a[0]-b[0]) + abs(a[1]-b[1])

def astar(grid, start, end):
    """Return (path_list, visited_list) in traversal order, or (None, visited_list)."""
    rows = len(grid)
    cols = len(grid[0]) if grid else 0
    open_set  = []
    heapq.heappush(open_set, (0, start))
    came_from = {}
    g_score   = {start: 0}
    visited_ordered = []   # ← ordered so we can animate step by step
    visited_set     = set()

    while open_set:
        _, cur = heapq.heappop(open_set)
        if cur in visited_set:
            continue
        visited_set.add(cur)
        visited_ordered.append(cur)

        if cur == end:
            # Reconstruct path in start→end order
            path = []
            node = cur
            while node in came_from:
                path.append(node)
                node = came_from[node]
            path.append(start)
            path.reverse()
            return path, visited_ordered

        r, c = cur
        for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
            nr, nc = r+dr, c+dc
            if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] != 1:
                ng = g_score[cur] + 1
                nb = (nr, nc)
                if ng < g_score.get(nb, 1e9):
                    g_score[nb]   = ng
                    came_from[nb] = cur
                    f = ng + heuristic(nb, end)
                    heapq.heappush(open_set, (f, nb))

    return None, visited_ordered



def dijkstra(grid, start, end):
    """Dijkstra — uniform cost, no heuristic. Returns (path_list, visited_list)."""
    rows = len(grid)
    cols = len(grid[0]) if grid else 0
    open_set        = []
    heapq.heappush(open_set, (0, start))
    came_from       = {}
    dist            = {start: 0}
    visited_ordered = []
    visited_set     = set()

    while open_set:
        cost, cur = heapq.heappop(open_set)
        if cur in visited_set:
            continue
        visited_set.add(cur)
        visited_ordered.append(cur)

        if cur == end:
            path = []
            node = cur
            while node in came_from:
                path.append(node)
                node = came_from[node]
            path.append(start)
            path.reverse()
            return path, visited_ordered

        r, c = cur
        for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
            nr, nc = r+dr, c+dc
            if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] != 1:
                nd = cost + 1
                nb = (nr, nc)
                if nd < dist.get(nb, 1e9):
                    dist[nb]      = nd
                    came_from[nb] = cur
                    heapq.heappush(open_set, (nd, nb))

    return None, visited_ordered


# ══════════════════════════════════════════════════════════════════════════════
# Event Queue / Priority Queue Simulator
# ══════════════════════════════════════════════════════════════════════════════

import random

EVENT_NAMES = ["Payment", "Alert", "Backup", "Email", "Report",
               "Deploy", "Sync",  "Cleanup","Update","Notify"]

class EventSim:
    def __init__(self):
        self.events = []
        self.log    = []
        self._id    = 0
        self.mode   = "priority"

    def add_random(self):
        self._id += 1
        self.events.append({
            "id":       self._id,
            "priority": random.randint(1, 10),
            "name":     random.choice(EVENT_NAMES),
            "time":     self._id,
        })

    def process_next(self):
        if not self.events:
            return None, None
        if self.mode == "priority":
            idx = min(range(len(self.events)),
                      key=lambda i: (self.events[i]["priority"], self.events[i]["id"]))
        else:
            idx = min(range(len(self.events)),
                      key=lambda i: self.events[i]["id"])
        ev  = self.events.pop(idx)
        tag = f"P{ev['priority']}" if self.mode == "priority" else f"T{ev['time']}"
        self.log.append(f"[{tag}] {ev['name']} processed")
        return ev["priority"], ev["name"]

    def sorted_items(self):
        if self.mode == "priority":
            return sorted(self.events, key=lambda e: (e["priority"], e["id"]))
        return sorted(self.events, key=lambda e: e["id"])


# ══════════════════════════════════════════════════════════════════════════════
# DP Grid – path counting with obstacles
# ══════════════════════════════════════════════════════════════════════════════

DP_ROWS, DP_COLS = 6, 9
DP_CELL = 58

def dp_count_paths(grid):
    R, C = len(grid), len(grid[0])
    dp   = [[0]*C for _ in range(R)]
    if grid[0][0] == 1:
        return dp
    dp[0][0] = 1
    for c in range(1, C):
        dp[0][c] = 0 if grid[0][c] == 1 else dp[0][c-1]
    for r in range(1, R):
        dp[r][0] = 0 if grid[r][0] == 1 else dp[r-1][0]
    for r in range(1, R):
        for c in range(1, C):
            dp[r][c] = 0 if grid[r][c] == 1 else dp[r-1][c] + dp[r][c-1]
    return dp

def dp_reconstruct(dp, grid):
    R, C = len(dp), len(dp[0])
    path = set()
    r, c = R-1, C-1
    if dp[r][c] == 0:
        return path
    path.add((r, c))
    while r > 0 or c > 0:
        if r == 0:               c -= 1
        elif c == 0:             r -= 1
        elif dp[r-1][c] >= dp[r][c-1]: r -= 1
        else:                    c -= 1
        path.add((r, c))
    return path


# ══════════════════════════════════════════════════════════════════════════════
# Main Puzzles Module
# ══════════════════════════════════════════════════════════════════════════════

# Animation speeds (frames between each revealed cell)
VISIT_SPEED = 1   # 1 frame per visited cell  (fast sweep)
PATH_SPEED  = 3   # 3 frames per path cell    (slower, more visible)

class PuzzlesModule(BaseModule):
    title = "Puzzle Challenges — Pathfinding · Event Queue · DP Grid"

    def reset(self):
        self.tab = 0
        self._reset_pathfinding()
        self._reset_event_sim()
        self._reset_dp()
        self.buttons = []
        self._build_buttons()

    # ── tab buttons + sub-buttons ─────────────────────────────────────────
    def _build_buttons(self):
        self.buttons = []
        for i, t in enumerate(TABS):
            self._make_button(20 + i * 240, 52, 230, 30, t,
                              lambda idx=i: self._switch_tab(idx))
        if self.tab == 0:
            self._make_button(20,  90, 110, 28, "Run A*",     self._run_astar)
            self._make_button(140, 90, 110, 28, "Clear Path", self._clear_path)
            self._make_button(260, 90, 110, 28, "Clear Grid", self._clear_grid)
            self._make_button(380, 90, 60,  28, "Start=?",    self._set_start_mode)
            self._make_button(450, 90, 60,  28, "End=?",      self._set_end_mode)
            self._make_button(530, 90, 55,  28, "A*",          self._pf_use_astar)
            self._make_button(595, 90, 75,  28, "Dijkstra",    self._pf_use_dijkstra)
        elif self.tab == 1:
            self._make_button(20,  90, 120, 28, "Add Event",    self._eq_add)
            self._make_button(150, 90, 130, 28, "Process Next", self._eq_process)
            self._make_button(290, 90, 90,  28, "Clear",        self._eq_clear)
            self._make_button(400, 90, 100, 28, "Priority",     self._eq_mode_priority)
            self._make_button(510, 90, 80,  28, "Time",         self._eq_mode_time)
        elif self.tab == 2:
            self._make_button(20,  90, 110, 28, "Solve DP",   self._dp_solve)
            self._make_button(140, 90, 110, 28, "Show Path",  self._dp_show_path)
            self._make_button(260, 90, 90,  28, "Clear",      self._dp_clear)

    def _switch_tab(self, idx):
        self.tab = idx
        self._build_buttons()

    # ── Pathfinding ───────────────────────────────────────────────────────
    def _reset_pathfinding(self):
        self.pf_grid        = [[0]*COLS for _ in range(ROWS)]
        self.pf_start       = (0, 0)
        self.pf_end         = (ROWS-1, COLS-1)
        self.pf_path        = set()      # final displayed path (set)
        self.pf_visited     = set()      # final displayed visited (set)
        self.pf_mode        = "wall"
        self.pf_msg         = "Left-click to place/remove walls. Set start/end then Run A*."
        self.pf_drawing     = False
        self.pf_algo        = "astar"   # "astar" | "dijkstra"
        # Animation state
        self._anim_visited  = []         # ordered list of all visited cells
        self._anim_path     = []         # ordered list of path cells
        self._anim_vis_idx  = 0          # how many visited cells shown so far
        self._anim_path_idx = 0          # how many path cells shown so far
        self._anim_phase    = "idle"     # "idle" | "visiting" | "pathing" | "done"
        self._anim_timer    = 0          # frame counter between steps

    def _run_astar(self):
        # Clear old display first
        self.pf_path    = set()
        self.pf_visited = set()

        if self.pf_algo == "dijkstra":
            path_list, visited_list = dijkstra(self.pf_grid, self.pf_start, self.pf_end)
            algo_name = "Dijkstra"
        else:
            path_list, visited_list = astar(self.pf_grid, self.pf_start, self.pf_end)
            algo_name = "A*"

        self._anim_visited  = visited_list
        self._anim_path     = path_list if path_list else []
        self._anim_vis_idx  = 0
        self._anim_path_idx = 0
        self._anim_timer    = 0
        self._anim_phase    = "visiting"

        if path_list:
            self.pf_msg = f"[{algo_name}] Searching… (path = {len(path_list)-1} steps)"
        else:
            self.pf_msg = f"[{algo_name}] Searching… (no path exists)"

    def _clear_path(self):
        self.pf_path        = set()
        self.pf_visited     = set()
        self._anim_phase    = "idle"
        self.pf_msg         = "Path cleared."

    def _clear_grid(self):
        self._reset_pathfinding()

    def _set_start_mode(self):
        self.pf_mode = "start"
        self.pf_msg  = "Click a cell to set the START node."

    def _set_end_mode(self):
        self.pf_mode = "end"
        self.pf_msg  = "Click a cell to set the END node."

    def _pf_use_astar(self):
        self.pf_algo = "astar"
        self.pf_msg  = "Algorithm: A*  (heuristic-guided, faster to goal)."
        self._clear_path()

    def _pf_use_dijkstra(self):
        self.pf_algo = "dijkstra"
        self.pf_msg  = "Algorithm: Dijkstra  (uniform cost, explores all directions)."
        self._clear_path()

    def _pf_grid_offset(self):
        ox = (WIDTH - COLS * CELL) // 2
        oy = 130
        return ox, oy

    def _cell_from_mouse(self, pos):
        ox, oy = self._pf_grid_offset()
        c = (pos[0] - ox) // CELL
        r = (pos[1] - oy) // CELL
        if 0 <= r < ROWS and 0 <= c < COLS:
            return r, c
        return None

    # ── Event Queue ───────────────────────────────────────────────────────
    def _reset_event_sim(self):
        self.eq     = EventSim()
        self.eq_msg = "Mode: Priority — events processed by lowest priority number first."

    def _eq_add(self):
        self.eq.add_random()
        self.eq_msg = f"Event added. Queue size: {len(self.eq.events)}"

    def _eq_process(self):
        pri, name = self.eq.process_next()
        if name:
            self.eq_msg = f"Processed: [{pri}] {name}"
        else:
            self.eq_msg = "Queue is empty!"

    def _eq_clear(self):
        self._reset_event_sim()

    def _eq_mode_priority(self):
        self.eq.mode = "priority"
        self.eq_msg  = "Mode: Priority — lowest priority number processed first."

    def _eq_mode_time(self):
        self.eq.mode = "time"
        self.eq_msg  = "Mode: Time — earliest added event processed first (FIFO)."

    # ── DP Grid ───────────────────────────────────────────────────────────
    def _reset_dp(self):
        self.dp_grid = [[0]*DP_COLS for _ in range(DP_ROWS)]
        self.dp_vals = None
        self.dp_path = set()
        self.dp_msg  = "Click cells to toggle obstacles, then Solve DP."

    def _dp_solve(self):
        self.dp_vals = dp_count_paths(self.dp_grid)
        self.dp_path = set()
        total = self.dp_vals[DP_ROWS-1][DP_COLS-1]
        self.dp_msg = f"Paths from (0,0) to ({DP_ROWS-1},{DP_COLS-1}): {total}"

    def _dp_show_path(self):
        if self.dp_vals is None:
            self._dp_solve()
        self.dp_path = dp_reconstruct(self.dp_vals, self.dp_grid)
        self.dp_msg  = "One optimal path shown in yellow."

    def _dp_clear(self):
        self._reset_dp()

    def _dp_grid_offset(self):
        ox = (WIDTH - DP_COLS * DP_CELL) // 2
        oy = 168
        return ox, oy

    # ── Event handling ────────────────────────────────────────────────────
    def handle_event(self, event):
        result = super().handle_event(event)
        if result:
            return result

        if self.tab == 0:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                cell = self._cell_from_mouse(event.pos)
                if cell:
                    if self.pf_mode == "start":
                        self.pf_start = cell
                        self.pf_mode  = "wall"
                        self.pf_msg   = f"Start set to {cell}."
                    elif self.pf_mode == "end":
                        self.pf_end  = cell
                        self.pf_mode = "wall"
                        self.pf_msg  = f"End set to {cell}."
                    else:
                        r, c = cell
                        if cell != self.pf_start and cell != self.pf_end:
                            self.pf_grid[r][c] ^= 1
                        self.pf_drawing = True
            if event.type == pygame.MOUSEBUTTONUP:
                self.pf_drawing = False
            if event.type == pygame.MOUSEMOTION and self.pf_drawing:
                cell = self._cell_from_mouse(event.pos)
                if cell and cell != self.pf_start and cell != self.pf_end:
                    r, c = cell
                    self.pf_grid[r][c] = 1

        elif self.tab == 2:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                ox, oy = self._dp_grid_offset()
                c = (event.pos[0] - ox) // DP_CELL
                r = (event.pos[1] - oy) // DP_CELL
                if 0 <= r < DP_ROWS and 0 <= c < DP_COLS:
                    if (r, c) not in [(0,0), (DP_ROWS-1, DP_COLS-1)]:
                        self.dp_grid[r][c] ^= 1
                        self.dp_vals = None
                        self.dp_path = set()

        return None

    # ── Update — drives the A* animation ─────────────────────────────────
    def update(self):
        if self._anim_phase == "idle" or self._anim_phase == "done":
            return

        self._anim_timer += 1

        if self._anim_phase == "visiting":
            # Reveal VISIT_SPEED visited cells per frame
            if self._anim_timer >= VISIT_SPEED:
                self._anim_timer = 0
                steps = max(1, len(self._anim_visited) // 60)  # batches for big grids
                for _ in range(steps):
                    if self._anim_vis_idx < len(self._anim_visited):
                        self.pf_visited.add(self._anim_visited[self._anim_vis_idx])
                        self._anim_vis_idx += 1
                    else:
                        # All visited cells shown — start path phase
                        self._anim_phase    = "pathing"
                        self._anim_timer    = 0
                        self._anim_path_idx = 0
                        if self._anim_path:
                            self.pf_msg = "Tracing path…"
                        else:
                            self.pf_msg  = "No path found!"
                            self._anim_phase = "done"
                        break

        elif self._anim_phase == "pathing":
            # Reveal one path cell every PATH_SPEED frames
            if self._anim_timer >= PATH_SPEED:
                self._anim_timer = 0
                if self._anim_path_idx < len(self._anim_path):
                    self.pf_path.add(self._anim_path[self._anim_path_idx])
                    self._anim_path_idx += 1
                else:
                    self._anim_phase = "done"
                    algo_label = "A*" if self.pf_algo == "astar" else "Dijkstra"
                    self.pf_msg = (
                        f"[{algo_label}]  Path = {len(self._anim_path)-1} steps   "
                        f"Cells explored = {len(self._anim_visited)}"
                    )

    # ── Draw ──────────────────────────────────────────────────────────────
    def draw(self):
        super().draw()

        for i, t in enumerate(TABS):
            rect = self.buttons[i][0]
            if i == self.tab:
                pygame.draw.rect(self.screen, ACCENT, rect, border_radius=8)
                lbl = self.fonts["small"].render(t, True, BG_DARK)
                self.screen.blit(lbl, lbl.get_rect(center=rect.center))

        if   self.tab == 0: self._draw_pathfinding()
        elif self.tab == 1: self._draw_event_sim()
        elif self.tab == 2: self._draw_dp()

    # ── Draw Pathfinding ──────────────────────────────────────────────────
    def _draw_pathfinding(self):
        ox, oy = self._pf_grid_offset()

        for r in range(ROWS):
            for c in range(COLS):
                x    = ox + c * CELL
                y    = oy + r * CELL
                cell = (r, c)

                if cell == self.pf_start:
                    col = START_COL
                elif cell == self.pf_end:
                    col = END_COL
                elif cell in self.pf_path:
                    col = PATH_COL
                elif cell in self.pf_visited:
                    # Pulse the frontier cell (most recently added visited cell)
                    if (self._anim_phase == "visiting" and
                            self._anim_vis_idx > 0 and
                            cell == self._anim_visited[self._anim_vis_idx - 1]):
                        col = (80, 180, 255)   # bright frontier flash
                    else:
                        col = VISIT_COL
                elif self.pf_grid[r][c] == 1:
                    col = WALL_COL
                else:
                    col = OPEN_COL

                pygame.draw.rect(self.screen, col,
                                 (x+1, y+1, CELL-2, CELL-2))
                pygame.draw.rect(self.screen, GRID_LINE,
                                 (x, y, CELL, CELL), 1)

        # Pulse glow on the latest path cell being drawn
        if self._anim_phase == "pathing" and self._anim_path_idx > 0:
            latest = self._anim_path[self._anim_path_idx - 1]
            lx = ox + latest[1] * CELL
            ly = oy + latest[0] * CELL
            pygame.draw.rect(self.screen, (255, 240, 120),
                             (lx, ly, CELL, CELL), 3)

        # Algo toggle button highlights (A* = index 5, Dijkstra = index 6)
        algo_btn_map = {5: "astar", 6: "dijkstra"}
        for btn_idx, algo_val in algo_btn_map.items():
            if btn_idx < len(self.buttons):
                rect   = self.buttons[btn_idx][0]
                active = (self.pf_algo == algo_val)
                pygame.draw.rect(self.screen,
                                 ACCENT if active else (50, 70, 110),
                                 rect, 3 if active else 1, border_radius=6)

        # Legend
        lx = ox + COLS * CELL + 16
        ly = oy
        for col, label in [(START_COL, "Start"), (END_COL, "End"),
                           (WALL_COL, "Wall"),   (PATH_COL, "Path"),
                           (VISIT_COL, "Visited")]:
            pygame.draw.rect(self.screen, col, (lx, ly, 16, 16))
            lbl = self.fonts["small"].render(label, True, TEXT_DIM)
            self.screen.blit(lbl, (lx + 20, ly))
            ly += 24

        self._draw_message(self.pf_msg, HEIGHT - 22, ACCENT2)

    # ── Draw Event Sim ────────────────────────────────────────────────────
    def _draw_event_sim(self):
        items = self.eq.sorted_items()

        CONTENT_TOP = 135
        ROW_H       = 34
        COL_W       = 420
        LOG_X       = COL_W + 70

        mode_labels = {6: "priority", 7: "time"}
        for btn_idx, mode_val in mode_labels.items():
            if btn_idx < len(self.buttons):
                rect       = self.buttons[btn_idx][0]
                active     = (self.eq.mode == mode_val)
                border_col = ACCENT if active else (50, 70, 110)
                border_w   = 3 if active else 1
                pygame.draw.rect(self.screen, border_col, rect,
                                 border_w, border_radius=6)

        mode_label = "Priority order" if self.eq.mode == "priority" else "Time order (FIFO)"
        queue_hdr  = self.fonts["body"].render(
            f"Event Queue  ({len(items)} pending)", True, ACCENT)
        self.screen.blit(queue_hdr, (20, CONTENT_TOP))

        mode_txt = self.fonts["small"].render(
            f"Sorting by: {mode_label}", True, TEXT_DIM)
        self.screen.blit(mode_txt, (20, CONTENT_TOP + 22))

        log_hdr = self.fonts["body"].render("Processed", True, ACCENT2)
        self.screen.blit(log_hdr, (LOG_X, CONTENT_TOP))

        DIV_Y = CONTENT_TOP + 48
        pygame.draw.line(self.screen, (40, 60, 110),
                         (20, DIV_Y), (WIDTH - 20, DIV_Y), 1)

        LIST_TOP = DIV_Y + 8
        for i, ev in enumerate(items[:12]):
            pri   = ev["priority"]
            name  = ev["name"]
            eid   = ev["id"]
            row_y = LIST_TOP + i * ROW_H
            row   = pygame.Rect(20, row_y, COL_W, ROW_H - 4)

            heat = max(0, 10 - pri) * 20
            fill = (min(255, 50 + heat), 30, max(0, 80 - heat))
            pygame.draw.rect(self.screen, fill,  row, border_radius=6)
            pygame.draw.rect(self.screen, ACCENT, row, 1, border_radius=6)

            badge = pygame.Rect(row.x + 6, row.y + 4, 52, ROW_H - 12)
            pygame.draw.rect(self.screen, (30, 30, 60), badge, border_radius=4)
            badge_str = f"P{pri:02d}" if self.eq.mode == "priority" else f"T{eid:02d}"
            badge_txt = self.fonts["small"].render(badge_str, True, ACCENT)
            self.screen.blit(badge_txt, badge_txt.get_rect(center=badge.center))

            secondary = f"t={eid}" if self.eq.mode == "priority" else f"p={pri}"
            sec_txt = self.fonts["small"].render(secondary, True, TEXT_DIM)
            self.screen.blit(sec_txt, (row.x + 66, row_y + 9))

            name_txt = self.fonts["small"].render(name, True, TEXT_LIGHT)
            self.screen.blit(name_txt, (row.x + 120, row_y + 9))

        for i, entry in enumerate(self.eq.log[-14:]):
            lbl = self.fonts["small"].render(entry, True, TEXT_DIM)
            self.screen.blit(lbl, (LOG_X, LIST_TOP + i * 28))

        self._draw_message(self.eq_msg, HEIGHT - 22, ACCENT2)

    # ── Draw DP Grid ──────────────────────────────────────────────────────
    def _draw_dp(self):
        ox, oy = self._dp_grid_offset()
        for r in range(DP_ROWS):
            for c in range(DP_COLS):
                x    = ox + c * DP_CELL
                y    = oy + r * DP_CELL
                cell = (r, c)
                if self.dp_grid[r][c] == 1:
                    fill = WALL_COL
                elif cell in self.dp_path:
                    fill = PATH_COL
                elif (r, c) == (0, 0):
                    fill = START_COL
                elif (r, c) == (DP_ROWS-1, DP_COLS-1):
                    fill = END_COL
                else:
                    fill = OPEN_COL
                pygame.draw.rect(self.screen, fill,
                                 (x+1, y+1, DP_CELL-2, DP_CELL-2), border_radius=4)
                pygame.draw.rect(self.screen, GRID_LINE,
                                 (x, y, DP_CELL, DP_CELL), 1)

                if self.dp_vals and self.dp_grid[r][c] == 0:
                    v   = self.dp_vals[r][c]
                    txt = self.fonts["small"].render(
                        str(v), True,
                        BG_DARK if cell in self.dp_path else TEXT_DIM)
                    self.screen.blit(txt, txt.get_rect(
                        center=(x + DP_CELL//2, y + DP_CELL//2)))

        hint = self.fonts["small"].render(
            "Click cells to toggle walls  |  S = start    G = goal", True, TEXT_DIM)
        self.screen.blit(hint, hint.get_rect(midtop=(WIDTH//2, 130)))

        self._draw_message(self.dp_msg, HEIGHT - 22, ACCENT2)