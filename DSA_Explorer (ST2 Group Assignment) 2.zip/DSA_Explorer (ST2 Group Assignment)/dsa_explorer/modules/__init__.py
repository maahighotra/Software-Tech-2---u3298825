"""Shared base class for all DSA modules."""
import pygame

WIDTH, HEIGHT = 1000, 700

BG_DARK    = (15,  20,  40)
ACCENT     = (0,  200, 160)
ACCENT2    = (255, 160,  50)
ACCENT3    = (200,  80, 255)
TEXT_LIGHT = (220, 230, 255)
TEXT_DIM   = (120, 130, 160)
PANEL      = (25,  35,  65)
BTN_HOVER  = (30,  50,  90)
BTN_NORMAL = (20,  35,  70)
RED        = (255,  80,  80)
GREEN      = (80,  220, 120)
YELLOW     = (255, 220,  60)
BLUE       = (80,  140, 255)
PURPLE     = (180,  80, 255)
ORANGE     = (255, 140,  40)


class BaseModule:
    """Every module inherits this."""
    def __init__(self, screen, fonts):
        self.screen = screen
        self.fonts  = fonts
        self.buttons: list[tuple[pygame.Rect, str, callable]] = []

    def reset(self):
        pass

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            return "menu"
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for rect, _, cb in self.buttons:
                if rect.collidepoint(event.pos):
                    cb()
        return None

    def update(self):
        pass

    def draw(self):
        self.screen.fill(BG_DARK)
        self._draw_header()
        self._draw_buttons()

    def _draw_header(self):
        title = self.fonts["card"].render(self.title, True, ACCENT)
        self.screen.blit(title, (20, 12))
        esc = self.fonts["small"].render("ESC → Menu", True, TEXT_DIM)
        self.screen.blit(esc, (WIDTH - 120, 18))
        pygame.draw.line(self.screen, (40, 60, 110), (0, 44), (WIDTH, 44), 1)

    def _draw_buttons(self):
        mx, my = pygame.mouse.get_pos()
        for rect, label, _ in self.buttons:
            hover = rect.collidepoint(mx, my)
            col = BTN_HOVER if hover else BTN_NORMAL
            pygame.draw.rect(self.screen, col, rect, border_radius=8)
            pygame.draw.rect(self.screen, ACCENT if hover else (50, 80, 130),
                             rect, 1, border_radius=8)
            lbl = self.fonts["small"].render(label, True,
                                             TEXT_LIGHT if hover else TEXT_DIM)
            self.screen.blit(lbl, lbl.get_rect(center=rect.center))

    def _make_button(self, x, y, w, h, label, callback):
        rect = pygame.Rect(x, y, w, h)
        self.buttons.append((rect, label, callback))
        return rect

    def _draw_message(self, msg, y=660, color=None):
        color = color or TEXT_DIM
        surf = self.fonts["small"].render(msg, True, color)
        self.screen.blit(surf, surf.get_rect(center=(WIDTH // 2, y)))
