"""
Phase 1 – Data Structures Module
Visualises: Stack, Queue, Linked List, Binary Search Tree
"""

import pygame
import math
import random
from modules import BaseModule, WIDTH, HEIGHT
from modules import (ACCENT, ACCENT2, ACCENT3, TEXT_LIGHT, TEXT_DIM,
                     PANEL, RED, GREEN, YELLOW, BLUE, BG_DARK)

# ── Colours ──────────────────────────────────────────────────────────────────
NODE_FILL   = (30, 55, 110)
NODE_BORDER = ACCENT
HIGHLIGHT   = (255, 200,  60)
LINK_COL    = (80, 160, 220)


# ═══════════════════════════════════════════════════════════════════════════
# Pure data-structure logic
# ═══════════════════════════════════════════════════════════════════════════

class Stack:
    def __init__(self):
        self._data = []

    def push(self, val):
        self._data.append(val)

    def pop(self):
        if self._data:
            return self._data.pop()
        return None

    def peek(self):
        return self._data[-1] if self._data else None

    def __len__(self):
        return len(self._data)

    def items(self):
        return list(self._data)


class Queue:
    def __init__(self):
        self._data = []

    def enqueue(self, val):
        self._data.append(val)

    def dequeue(self):
        if self._data:
            return self._data.pop(0)
        return None

    def __len__(self):
        return len(self._data)

    def items(self):
        return list(self._data)


class LinkedListNode:
    def __init__(self, val):
        self.val  = val
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def insert(self, val, pos=None):
        node = LinkedListNode(val)
        if self.head is None or pos == 0:
            node.next = self.head
            self.head  = node
            return
        cur = self.head
        idx = 0
        while cur.next and (pos is None or idx < pos - 1):
            cur = cur.next
            idx += 1
        node.next = cur.next
        cur.next  = node

    def delete(self, val):
        if self.head is None:
            return False
        if self.head.val == val:
            self.head = self.head.next
            return True
        cur = self.head
        while cur.next:
            if cur.next.val == val:
                cur.next = cur.next.next
                return True
            cur = cur.next
        return False

    def reverse(self):
        prev, cur = None, self.head
        while cur:
            nxt      = cur.next
            cur.next = prev
            prev     = cur
            cur      = nxt
        self.head = prev

    def to_list(self):
        result, cur = [], self.head
        while cur:
            result.append(cur.val)
            cur = cur.next
        return result


class BSTNode:
    def __init__(self, val):
        self.val   = val
        self.left  = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, val):
        def _ins(node, v):
            if node is None:
                return BSTNode(v)
            if v < node.val:
                node.left  = _ins(node.left,  v)
            elif v > node.val:
                node.right = _ins(node.right, v)
            return node
        self.root = _ins(self.root, val)

    def inorder(self):
        result = []
        def _in(n):
            if n:
                _in(n.left); result.append(n.val); _in(n.right)
        _in(self.root)
        return result

    def preorder(self):
        result = []
        def _pre(n):
            if n:
                result.append(n.val); _pre(n.left); _pre(n.right)
        _pre(self.root)
        return result

    def postorder(self):
        result = []
        def _post(n):
            if n:
                _post(n.left); _post(n.right); result.append(n.val)
        _post(self.root)
        return result


# ═══════════════════════════════════════════════════════════════════════════
# Drawing helpers
# ═══════════════════════════════════════════════════════════════════════════

def draw_node(surface, cx, cy, label, font, highlight=False, radius=24):
    fill   = HIGHLIGHT if highlight else NODE_FILL
    border = (255, 80, 80) if highlight else NODE_BORDER
    pygame.draw.circle(surface, fill,   (cx, cy), radius)
    pygame.draw.circle(surface, border, (cx, cy), radius, 2)
    txt = font.render(str(label), True, BG_DARK if highlight else TEXT_LIGHT)
    surface.blit(txt, txt.get_rect(center=(cx, cy)))


def draw_arrow(surface, x1, y1, x2, y2, color=LINK_COL):
    pygame.draw.line(surface, color, (x1, y1), (x2, y2), 2)
    angle = math.atan2(y2 - y1, x2 - x1)
    size  = 10
    ax    = x2 - size * math.cos(angle - 0.4)
    ay    = y2 - size * math.sin(angle - 0.4)
    bx    = x2 - size * math.cos(angle + 0.4)
    by    = y2 - size * math.sin(angle + 0.4)
    pygame.draw.polygon(surface, color, [(x2, y2), (int(ax), int(ay)),
                                          (int(bx), int(by))])


def _make_bst_order(n=99):
    return []
BST_INSERT_ORDER = []


# ═══════════════════════════════════════════════════════════════════════════
# Animation state
# ═══════════════════════════════════════════════════════════════════════════

# Each animation is a dict:
#   kind  : "push" | "pop"
#   val   : the value being animated
#   t     : current frame (0..ANIM_FRAMES)
#   start : (x, y) pixel start
#   end   : (x, y) pixel end
#   alpha : current opacity (0-255) — used for pop fade-out

ANIM_FRAMES = 22   # total frames for one animation (~22 frames at 60fps ≈ 0.37s)

TABS = ["Stack", "Queue", "Linked List", "BST"]

class DataStructuresModule(BaseModule):
    title = "Data Structures — Stack · Queue · Linked List · BST"

    def reset(self):
        self.tab       = 0
        self.stack     = Stack()
        self.queue     = Queue()
        self.ll        = LinkedList()
        self.bst       = BST()
        self._next     = 1
        self._bst_idx  = 0
        self.message   = "Welcome! Use buttons to interact."
        self.highlight = None
        self.hl_timer  = 0
        self.buttons   = []
        # Animation state
        self.anim      = None   # None or dict described above
        self._build_buttons()

    # ── Value generators ───────────────────────────────────────────────────
    def _next_val(self):
        v = self._next
        self._next = (self._next % 99) + 1
        return v

    def _next_bst_val(self):
        existing = self.bst.inorder()
        if len(existing) >= 51:
            return random.randint(0, 50)
        while True:
            v = random.randint(0, 50)
            if v not in existing:
                return v

    def _build_buttons(self):
        self.buttons = []
        for i, t in enumerate(TABS):
            self._make_button(20 + i * 130, 52, 120, 30, t,
                              lambda idx=i: self._switch_tab(idx))

        if self.tab == 0:
            self._make_button(20,  110, 120, 34, "Push",  self._stack_push)
            self._make_button(150, 110, 120, 34, "Pop",   self._stack_pop)
            self._make_button(280, 110, 120, 34, "Peek",  self._stack_peek)
            self._make_button(410, 110, 120, 34, "Clear", self._stack_clear)

        elif self.tab == 1:
            self._make_button(20,  110, 130, 34, "Enqueue", self._q_enqueue)
            self._make_button(160, 110, 130, 34, "Dequeue", self._q_dequeue)
            self._make_button(300, 110, 120, 34, "Clear",   self._q_clear)

        elif self.tab == 2:
            self._make_button(20,  110, 140, 34, "Insert Head", self._ll_insert_head)
            self._make_button(170, 110, 140, 34, "Insert Tail", self._ll_insert_tail)
            self._make_button(320, 110, 140, 34, "Delete Head", self._ll_delete_head)
            self._make_button(470, 110, 100, 34, "Reverse",     self._ll_reverse)
            self._make_button(580, 110, 90,  34, "Clear",       self._ll_clear)

        elif self.tab == 3:
            self._make_button(20,  110, 110, 34, "Insert",    self._bst_insert)
            self._make_button(140, 110, 110, 34, "Inorder",   self._bst_inorder)
            self._make_button(260, 110, 110, 34, "Preorder",  self._bst_preorder)
            self._make_button(380, 110, 110, 34, "Postorder", self._bst_postorder)
            self._make_button(500, 110, 90,  34, "Clear",     self._bst_clear)

    def _switch_tab(self, idx):
        self.tab = idx
        self.anim = None
        self.message = ""
        self._build_buttons()

    # ── Animation helpers ──────────────────────────────────────────────────
    def _stack_slot_y(self, stack_size, slot_index, base_y, slot_h):
        """Y-centre of a stack slot (0 = bottom slot)."""
        return base_y - (slot_index + 1) * slot_h + slot_h // 2

    def _start_push_anim(self, val, cx, base_y, slot_h):
        """Node drops in from above onto the top of the stack."""
        top_slot = len(self.stack) - 1   # already pushed
        end_y    = self._stack_slot_y(len(self.stack), top_slot, base_y, slot_h)
        self.anim = {
            "kind":  "push",
            "val":   val,
            "t":     0,
            "start": (cx, base_y - 9 * slot_h),   # starts well above the stack
            "end":   (cx, end_y),
            "alpha": 255,
        }

    def _start_pop_anim(self, val, cx, base_y, slot_h, stack_size_before):
        """Node flies upward and fades out."""
        top_slot = stack_size_before - 1
        start_y  = self._stack_slot_y(stack_size_before, top_slot, base_y, slot_h)
        self.anim = {
            "kind":  "pop",
            "val":   val,
            "t":     0,
            "start": (cx, start_y),
            "end":   (cx, start_y - 8 * slot_h),   # flies upward
            "alpha": 255,
        }

    # ── Stack operations ───────────────────────────────────────────────────
    def _stack_push(self):
        v = self._next_val()
        self.stack.push(v)
        self.message = f"Pushed {v}  (size={len(self.stack)})"
        self.highlight = v
        self.hl_timer  = 40
        # Kick off animation (geometry computed lazily in draw using stored params)
        self.anim = {"kind": "push", "val": v, "t": 0,
                     "start": None, "end": None, "alpha": 255,
                     "pending_geometry": True}

    def _stack_pop(self):
        if not self.stack.items():
            self.message = "Stack is empty!"
            return
        size_before = len(self.stack)
        v = self.stack.pop()
        self.message = f"Popped {v}"
        if len(self.stack) == 0:
            self._next = 1
        self.anim = {"kind": "pop", "val": v, "t": 0,
                     "start": None, "end": None, "alpha": 255,
                     "size_before": size_before,
                     "pending_geometry": True}

    def _stack_peek(self):
        v = self.stack.peek()
        self.message = f"Peek → {v}" if v is not None else "Stack is empty!"
        if v is not None:
            self.highlight = v; self.hl_timer = 40

    def _stack_clear(self):
        self.stack = Stack()
        self.anim  = None
        self.message = "Stack cleared."
        self._next = 1

    # ── Queue operations ───────────────────────────────────────────────────
    def _q_enqueue(self):
        v = self._next_val()
        self.queue.enqueue(v)
        self.message = f"Enqueued {v}  (size={len(self.queue)})"
        self.highlight = v; self.hl_timer = 40

    def _q_dequeue(self):
        v = self.queue.dequeue()
        if v is not None:
            self.message = f"Dequeued {v}"
            if len(self.queue) == 0: self._next = 1
        else:
            self.message = "Queue is empty!"

    def _q_clear(self):
        self.queue = Queue()
        self.message = "Queue cleared."
        self._next = 1

    # ── Linked List operations ─────────────────────────────────────────────
    def _ll_insert_head(self):
        v = self._next_val()
        self.ll.insert(v, 0)
        self.message = f"Inserted {v} at head."
        self.highlight = v; self.hl_timer = 40

    def _ll_insert_tail(self):
        v = self._next_val()
        self.ll.insert(v)
        self.message = f"Inserted {v} at tail."
        self.highlight = v; self.hl_timer = 40

    def _ll_delete_head(self):
        if self.ll.head:
            v = self.ll.head.val
            self.ll.delete(v)
            self.message = f"Deleted head ({v})."
            if self.ll.head is None: self._next = 1
        else:
            self.message = "List is empty!"

    def _ll_reverse(self):
        self.ll.reverse()
        self.message = "List reversed."

    def _ll_clear(self):
        self.ll = LinkedList()
        self.message = "List cleared."
        self._next = 1

    # ── BST operations ─────────────────────────────────────────────────────
    def _bst_insert(self):
        v = self._next_bst_val()
        self.bst.insert(v)
        self.message = f"Inserted {v} into BST."
        self.highlight = v; self.hl_timer = 50

    def _bst_inorder(self):
        self.message = f"Inorder: {self.bst.inorder()}"

    def _bst_preorder(self):
        self.message = f"Preorder: {self.bst.preorder()}"

    def _bst_postorder(self):
        self.message = f"Postorder: {self.bst.postorder()}"

    def _bst_clear(self):
        self.bst      = BST()
        self._bst_idx = 0
        self.message  = "BST cleared."

    # ── Event / update ─────────────────────────────────────────────────────
    def handle_event(self, event):
        return super().handle_event(event)

    def update(self):
        if self.hl_timer > 0:
            self.hl_timer -= 1
        if self.hl_timer == 0:
            self.highlight = None

        # Advance animation
        if self.anim and not self.anim.get("pending_geometry"):
            self.anim["t"] += 1
            # Fade out during pop
            if self.anim["kind"] == "pop":
                self.anim["alpha"] = max(0, 255 - int(255 * self.anim["t"] / ANIM_FRAMES))
            if self.anim["t"] >= ANIM_FRAMES:
                self.anim = None

    # ── Draw ───────────────────────────────────────────────────────────────
    def draw(self):
        super().draw()
        for i, t in enumerate(TABS):
            rect = self.buttons[i][0]
            if i == self.tab:
                pygame.draw.rect(self.screen, ACCENT, rect, border_radius=8)
                lbl = self.fonts["small"].render(t, True, BG_DARK)
                self.screen.blit(lbl, lbl.get_rect(center=rect.center))

        area = pygame.Rect(10, 155, WIDTH - 20, HEIGHT - 200)
        pygame.draw.rect(self.screen, (18, 28, 55), area, border_radius=12)
        pygame.draw.rect(self.screen, (40, 60, 110), area, 1, border_radius=12)

        if   self.tab == 0: self._draw_stack(area)
        elif self.tab == 1: self._draw_queue(area)
        elif self.tab == 2: self._draw_ll(area)
        elif self.tab == 3: self._draw_bst(area)

        self._draw_message(self.message, HEIGHT - 22, ACCENT2)

    # ── Drawing Logic ──────────────────────────────────────────────────────
    def _draw_stack(self, area):
        items  = self.stack.items()
        cx     = area.centerx
        slot_h = 38
        base_y = area.bottom - 20
        max_show = min(len(items), 8)

        pygame.draw.line(self.screen, ACCENT,
                         (cx - 60, base_y), (cx + 60, base_y), 3)

        # ── Resolve pending animation geometry now that we know the layout ──
        if self.anim and self.anim.get("pending_geometry"):
            self.anim.pop("pending_geometry")
            if self.anim["kind"] == "push":
                # Top slot after push = index (len-1)
                top_slot = len(items) - 1
                end_y    = base_y - (top_slot + 1) * slot_h + slot_h // 2
                self.anim["start"] = (cx, end_y - 7 * slot_h)
                self.anim["end"]   = (cx, end_y)
            elif self.anim["kind"] == "pop":
                size_before = self.anim.pop("size_before")
                top_slot    = size_before - 1
                start_y     = base_y - (top_slot + 1) * slot_h + slot_h // 2
                self.anim["start"] = (cx, start_y)
                self.anim["end"]   = (cx, start_y - 7 * slot_h)

        # ── Draw static stack slots ─────────────────────────────────────────
        for i, val in enumerate(items[-max_show:]):
            y  = base_y - (i + 1) * slot_h + slot_h // 2
            hl = (val == self.highlight) and self.anim is None
            box = pygame.Rect(cx - 45, y - 16, 90, 32)
            pygame.draw.rect(self.screen,
                             HIGHLIGHT if hl else NODE_FILL, box, border_radius=6)
            pygame.draw.rect(self.screen,
                             ACCENT if hl else NODE_BORDER, box, 2, border_radius=6)
            lbl = self.fonts["body"].render(
                str(val), True, BG_DARK if hl else TEXT_LIGHT)
            self.screen.blit(lbl, lbl.get_rect(center=box.center))

        # ── Draw animated node ──────────────────────────────────────────────
        if self.anim and self.anim["start"] is not None:
            t_norm = self.anim["t"] / ANIM_FRAMES          # 0.0 → 1.0
            # Ease-out cubic for push (decelerates into place)
            # Linear for pop (constant upward drift)
            if self.anim["kind"] == "push":
                ease = 1 - (1 - t_norm) ** 3
            else:
                ease = t_norm

            sx, sy = self.anim["start"]
            ex, ey = self.anim["end"]
            ax = sx + (ex - sx) * ease
            ay = sy + (ey - sy) * ease

            alpha = self.anim["alpha"]
            val   = self.anim["val"]

            # Draw on a temp surface so we can apply alpha for the fade-out
            tmp = pygame.Surface((90, 32), pygame.SRCALPHA)
            box_col  = (*HIGHLIGHT, alpha)
            bord_col = (255, 80, 80, alpha)
            txt_col  = (*BG_DARK,  alpha)
            pygame.draw.rect(tmp, box_col,  (0, 0, 90, 32), border_radius=6)
            pygame.draw.rect(tmp, bord_col, (0, 0, 90, 32), 2, border_radius=6)
            txt = self.fonts["body"].render(str(val), True, txt_col)
            tmp.blit(txt, txt.get_rect(center=(45, 16)))
            self.screen.blit(tmp, (int(ax) - 45, int(ay) - 16))

    def _draw_queue(self, area):
        items = self.queue.items()
        cy = area.centery
        slot_w, gap = 70, 8
        start_x = area.left + 30
        for i, val in enumerate(items):
            x = start_x + i * (slot_w + gap)
            if x + slot_w > area.right - 10: break
            hl  = (val == self.highlight)
            box = pygame.Rect(x, cy - 22, slot_w, 44)
            pygame.draw.rect(self.screen, HIGHLIGHT if hl else NODE_FILL,
                             box, border_radius=6)
            pygame.draw.rect(self.screen, ACCENT if hl else NODE_BORDER,
                             box, 2, border_radius=6)
            lbl = self.fonts["body"].render(str(val), True,
                                            BG_DARK if hl else TEXT_LIGHT)
            self.screen.blit(lbl, lbl.get_rect(center=box.center))
            if i < len(items) - 1:
                draw_arrow(self.screen, x + slot_w, cy,
                           x + slot_w + gap, cy)

    def _draw_ll(self, area):
        nodes = self.ll.to_list()
        cy = area.centery
        node_w, gap = 70, 40
        start_x = area.left + 40
        for i, val in enumerate(nodes):
            x = start_x + i * (node_w + gap)
            if x + node_w > area.right - 20: break
            hl   = (val == self.highlight)
            vbox = pygame.Rect(x, cy - 22, node_w - 16, 44)
            pygame.draw.rect(self.screen, HIGHLIGHT if hl else NODE_FILL,
                             vbox, border_radius=6)
            pygame.draw.rect(self.screen, ACCENT if hl else NODE_BORDER,
                             vbox, 2, border_radius=6)
            lbl = self.fonts["body"].render(str(val), True,
                                            BG_DARK if hl else TEXT_LIGHT)
            self.screen.blit(lbl, lbl.get_rect(center=vbox.center))
            if i < len(nodes) - 1:
                draw_arrow(self.screen, x + node_w, cy,
                           x + node_w + gap - 5, cy)

    def _draw_bst(self, area):
        if self.bst.root is None:
            empty = self.fonts["body"].render(
                "Empty — insert nodes", True, TEXT_DIM)
            self.screen.blit(empty, empty.get_rect(center=area.center))
            return

        def get_max_depth(node):
            if not node:
                return 0
            return 1 + max(get_max_depth(node.left), get_max_depth(node.right))

        max_d    = get_max_depth(self.bst.root)
        usable_h = area.height - 60
        v_gap    = max(60, min(90, usable_h // max(1, max_d)))

        positions = {}

        def assign_positions(node, cx, cy, w_offset):
            if not node:
                return
            positions[node.val] = (int(cx), int(cy))
            next_offset = max(w_offset * 0.55, 25)
            if node.left:
                assign_positions(node.left,  cx - w_offset, cy + v_gap, next_offset)
            if node.right:
                assign_positions(node.right, cx + w_offset, cy + v_gap, next_offset)

        assign_positions(self.bst.root, area.centerx, area.top + 40,
                         (area.width - 100) / 4.0)

        def draw_edges(node):
            if not node:
                return
            if node.left:
                pygame.draw.line(self.screen, LINK_COL,
                                 positions[node.val], positions[node.left.val], 2)
                draw_edges(node.left)
            if node.right:
                pygame.draw.line(self.screen, LINK_COL,
                                 positions[node.val], positions[node.right.val], 2)
                draw_edges(node.right)

        draw_edges(self.bst.root)

        def draw_nodes(node):
            if not node:
                return
            cx, cy = positions[node.val]
            draw_node(self.screen, cx, cy, node.val, self.fonts["small"],
                      highlight=(node.val == self.highlight), radius=24)
            draw_nodes(node.left)
            draw_nodes(node.right)

        draw_nodes(self.bst.root)