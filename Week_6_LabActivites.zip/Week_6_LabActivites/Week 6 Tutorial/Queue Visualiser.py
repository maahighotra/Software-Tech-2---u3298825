import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
VERTICAL_GAP = 10
CANVAS_WIDTH = 300
CANVAS_HEIGHT = 500

MAX_STACK_SIZE = 50

class StackVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.stack = []

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Push Value:").grid(row=0, column=0)
        self.push_entry = tk.Entry(control_frame, width=10)
        self.push_entry.grid(row=0, column=1)

        push_btn = tk.Button(control_frame, text="Push", command=self.push_value)
        push_btn.grid(row=0, column=2, padx=5)

        pop_btn = tk.Button(control_frame, text="Pop", command=self.pop_value)
        pop_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_stack()

    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT, fill="lightblue", outline="black", width=2)
        self.canvas.create_text(x + NODE_WIDTH / 2, y + NODE_HEIGHT / 2, text=str(data), font=("Arial", 16))

    def draw_stack(self):
        self.canvas.delete("all")
        x = (CANVAS_WIDTH - NODE_WIDTH) // 2
        # Draw from bottom up, first element at bottom
        for i, val in enumerate(self.stack):
            y = CANVAS_HEIGHT - NODE_HEIGHT - 10 - i * (NODE_HEIGHT + VERTICAL_GAP)
            self.draw_node(x, y, val)
        # Label the top (last pushed)
        if self.stack:
            top_y = CANVAS_HEIGHT - NODE_HEIGHT - 10 - (len(self.stack) - 1) * (NODE_HEIGHT + VERTICAL_GAP)
            self.canvas.create_text(x + NODE_WIDTH + 40, top_y + NODE_HEIGHT / 2,
                                    text="Top", font=("Arial", 12), fill="red")

    def push_value(self):
        if len(self.stack) >= MAX_STACK_SIZE:
            messagebox.showerror("Stack Full", f"Stack is full. Maximum size is {MAX_STACK_SIZE}.")
            return
        try:
            val = int(self.push_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to push.")
            return
        self.stack.append(val)
        self.push_entry.delete(0, tk.END)
        self.status_label.config(text=f"Pushed {val} onto stack")
        self.draw_stack()

    def pop_value(self):
        if len(self.stack) == 0:
            messagebox.showinfo("Empty Stack", "Stack is empty. Cannot pop.")
            return
        val = self.stack.pop(0)  # remove first pushed (bottom of visual stack)
        self.status_label.config(text=f"Popped {val} from stack")
        self.draw_stack()

if __name__ == "__main__":
    root = tk.Tk()
    app = StackVisualizer(root)
    root.mainloop()