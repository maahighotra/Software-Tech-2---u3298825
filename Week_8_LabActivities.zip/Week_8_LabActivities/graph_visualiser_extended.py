from graph import Graph
import tkinter as tk
import math
import time
import threading


class NetworkDisplay(tk.Tk):
    def __init__(self, network):
        super().__init__()
        self.title("Graph Visualizer")
        self.geometry("650x700")
        self.network = network

        self.drawing_area = tk.Canvas(self, width=600, height=600, bg="white")
        self.drawing_area.pack(pady=10)

        self.node_coords = {}
        self.node_shapes = {}
        self.connection_lines = {}
        self.circle_radius = 20
        self.layout_spacing = 180
        self.canvas_center = (300, 300)

        button_row = tk.Frame(self)
        button_row.pack()

        tk.Button(button_row, text="Run BFS",
                command=lambda: self.start_traversal("bfs")).pack(side=tk.LEFT, padx=5)
        tk.Button(button_row, text="Run DFS",
                command=lambda: self.start_traversal("dfs")).pack(side=tk.LEFT, padx=5)
        tk.Button(button_row, text="Detect Undirected Cycle",
                command=self.check_undirected_cycle).pack(side=tk.LEFT, padx=5)
        tk.Button(button_row, text="Detect Directed Cycle",
                command=self.check_directed_cycle).pack(side=tk.LEFT, padx=5)
        tk.Button(button_row, text="Reset Colors",
                command=self.clear_highlights).pack(side=tk.LEFT, padx=5)

        self.status_label = tk.Label(self, text="")
        self.status_label.pack(pady=5)

        self.render_network()

    def render_network(self):
        self.drawing_area.delete("all")
        self.node_coords.clear()
        self.node_shapes.clear()
        self.connection_lines.clear()

        all_nodes = list(self.network.graph.keys())
        if not all_nodes:
            return

        cx, cy = self.canvas_center
        angle_step = 360 / len(all_nodes)

        for idx, node in enumerate(all_nodes):
            theta = math.radians(idx * angle_step)
            px = cx + self.layout_spacing * math.cos(theta)
            py = cy + self.layout_spacing * math.sin(theta)
            self.node_coords[node] = (px, py)

        for node in all_nodes:
            px, py = self.node_coords[node]
            shape_id = self.drawing_area.create_oval(
                px - self.circle_radius, py - self.circle_radius,
                px + self.circle_radius, py + self.circle_radius,
                fill="lightblue", outline="black", width=2
            )
            self.node_shapes[node] = shape_id
            self.drawing_area.create_text(px, py, text=node, font=("Arial", 12, "bold"))

        drawn_pairs = set()

        for node in all_nodes:
            x1, y1 = self.node_coords[node]

            for neighbour in self.network.graph[node]:
                if not self.network.directed:
                    pair_key = tuple(sorted((node, neighbour)))
                    if pair_key in drawn_pairs:
                        continue
                    drawn_pairs.add(pair_key)

                x2, y2 = self.node_coords[neighbour]
                delta_x, delta_y = x2 - x1, y2 - y1
                length = math.sqrt(delta_x * delta_x + delta_y * delta_y)
                if length == 0:
                    continue

                nudge_x = delta_x / length * self.circle_radius
                nudge_y = delta_y / length * self.circle_radius

                sx = x1 + nudge_x
                sy = y1 + nudge_y
                ex = x2 - nudge_x
                ey = y2 - nudge_y

                line_id = self.drawing_area.create_line(
                    sx, sy, ex, ey,
                    arrow=tk.LAST if self.network.directed else None,
                    width=2
                )

                if self.network.directed:
                    self.connection_lines[(node, neighbour)] = line_id
                else:
                    self.connection_lines[(node, neighbour)] = line_id
                    self.connection_lines[(neighbour, node)] = line_id

                if self.network.weighted:
                    edge_weight = self.network.weights.get((node, neighbour), "")
                    mid_x = (sx + ex) / 2
                    mid_y = (sy + ey) / 2
                    self.drawing_area.create_text(
                        mid_x, mid_y,
                        text=str(edge_weight),
                        fill="red",
                        font=("Arial", 10, "italic")
                    )

    def clear_highlights(self):
        for shape_id in self.node_shapes.values():
            self.drawing_area.itemconfig(shape_id, fill="lightblue")
        for line_id in set(self.connection_lines.values()):
            self.drawing_area.itemconfig(line_id, fill="black", width=2)
        self.status_label.config(text="")

    def colour_node(self, node, colour):
        shape_id = self.node_shapes.get(node)
        if shape_id:
            self.drawing_area.itemconfig(shape_id, fill=colour)
            self.update()

    def colour_edge(self, src, dst, colour):
        line_id = self.connection_lines.get((src, dst))
        if line_id:
            self.drawing_area.itemconfig(line_id, fill=colour, width=3)
            self.update()

    def start_traversal(self, mode):
        def worker():
            self.clear_highlights()

            origin = "A" if "A" in self.network.graph else next(iter(self.network.graph), None)
            if origin is None:
                self.status_label.config(text="Graph is empty")
                return

            seen = set()
            sequence = []

            if mode == "bfs":
                self.status_label.config(text="Running BFS...")
                pending = [origin]

                while pending:
                    current = pending.pop(0)
                    if current not in seen:
                        seen.add(current)
                        sequence.append(current)
                        self.colour_node(current, "orange")
                        self.status_label.config(text=f"BFS visiting: {current}")
                        time.sleep(0.6)

                        for nbr in self.network.graph[current]:
                            if nbr not in seen and nbr not in pending:
                                pending.append(nbr)
                                self.colour_edge(current, nbr, "green")
                                time.sleep(0.2)

                self.status_label.config(text=f"BFS complete: {' -> '.join(sequence)}")

            elif mode == "dfs":
                self.status_label.config(text="Running DFS...")
                pending = [origin]

                while pending:
                    current = pending.pop()
                    if current not in seen:
                        seen.add(current)
                        sequence.append(current)
                        self.colour_node(current, "purple")
                        self.status_label.config(text=f"DFS visiting: {current}")
                        time.sleep(0.6)

                        for nbr in reversed(self.network.graph[current]):
                            if nbr not in seen:
                                pending.append(nbr)
                                self.colour_edge(current, nbr, "blue")
                                time.sleep(0.2)

                self.status_label.config(text=f"DFS complete: {' -> '.join(sequence)}")

        threading.Thread(target=worker, daemon=True).start()

    def check_undirected_cycle(self):
        def worker():
            self.clear_highlights()

            if self.network.directed:
                self.status_label.config(text="Undirected cycle detection works only on undirected graphs.")
                return

            self.status_label.config(text="Detecting cycles in undirected graph...")
            explored = set()

            def search(current, came_from):
                explored.add(current)
                self.colour_node(current, "yellow")
                time.sleep(0.5)

                for nbr in self.network.graph[current]:
                    if nbr not in explored:
                        self.colour_edge(current, nbr, "orange")
                        time.sleep(0.3)
                        if search(nbr, current):
                            self.colour_node(current, "red")
                            self.colour_node(nbr, "red")
                            self.colour_edge(current, nbr, "red")
                            return True
                    elif nbr != came_from:
                        self.colour_node(current, "red")
                        self.colour_node(nbr, "red")
                        self.colour_edge(current, nbr, "red")
                        return True

                return False

            for node in self.network.graph:
                if node not in explored:
                    if search(node, None):
                        self.status_label.config(text="Cycle detected in the undirected graph!")
                        return

            self.status_label.config(text="No cycles found in the undirected graph.")

        threading.Thread(target=worker, daemon=True).start()

    def check_directed_cycle(self):
        def worker():
            self.clear_highlights()

            if not self.network.directed:
                self.status_label.config(text="Directed cycle detection works only on directed graphs.")
                return

            self.status_label.config(text="Detecting cycles in directed graph...")
            explored = set()
            active_path = set()

            def search(node):
                explored.add(node)
                active_path.add(node)
                self.colour_node(node, "yellow")
                time.sleep(0.5)

                for nbr in self.network.graph[node]:
                    if nbr not in explored:
                        self.colour_edge(node, nbr, "orange")
                        time.sleep(0.3)
                        if search(nbr):
                            self.colour_node(node, "red")
                            self.colour_node(nbr, "red")
                            self.colour_edge(node, nbr, "red")
                            return True
                    elif nbr in active_path:
                        self.colour_node(node, "red")
                        self.colour_node(nbr, "red")
                        self.colour_edge(node, nbr, "red")
                        return True

                active_path.remove(node)
                return False

            for node in self.network.graph:
                if node not in explored:
                    if search(node):
                        self.status_label.config(text="Cycle detected in the directed graph!")
                        return

            self.status_label.config(text="No cycles found in the directed graph.")

        threading.Thread(target=worker, daemon=True).start()


def make_undirected_graph():
    g = Graph(directed=False, weighted=False)
    for v in ["A", "B", "C", "D"]:
        g.add_vertex(v)
    g.add_edge("A", "B")
    g.add_edge("B", "C")
    g.add_edge("C", "A")
    g.add_edge("C", "D")
    return g


def make_directed_graph():
    g = Graph(directed=True, weighted=False)
    for v in ["A", "B", "C", "D"]:
        g.add_vertex(v)
    g.add_edge("A", "B")
    g.add_edge("B", "C")
    g.add_edge("C", "A")
    g.add_edge("C", "D")
    return g


if __name__ == "__main__":
    app = NetworkDisplay(make_directed_graph())
    app.mainloop()