from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        root = Tk()
        root.title("Koch Snowflake")

        self.width = 500
        self.height = 500

        self.canvas = Canvas(root, width=self.width, height=self.height)
        self.canvas.pack()

        # Frame for input
        control_frame = Frame(root)
        control_frame.pack()

        Label(control_frame, text="Enter an order: ").pack(side=LEFT)
        self.depth_input = StringVar()
        Entry(control_frame, textvariable=self.depth_input, justify=RIGHT).pack(side=LEFT)
        Button(control_frame, text="Display Koch Snowflake", command=self.render).pack(side=LEFT)

        root.mainloop()

    def render(self):
        # Clear previous lines
        self.canvas.delete("line")

        # Create equilateral triangle
        base_size = 300
        vertex_left  = [self.width / 2 - base_size / 2, self.height / 2 + base_size / 3]
        vertex_right = [self.width / 2 + base_size / 2, self.height / 2 + base_size / 3]
        tri_height   = base_size * math.sqrt(3) / 2
        vertex_top   = [self.width / 2, self.height / 2 - 2 * tri_height / 3]

        # Draw 3 sides recursively
        self.draw_fractal(vertex_left,  vertex_right, int(self.depth_input.get()))
        self.draw_fractal(vertex_right, vertex_top,   int(self.depth_input.get()))
        self.draw_fractal(vertex_top,   vertex_left,  int(self.depth_input.get()))

    def draw_fractal(self, base_left, base_right, order):
        if order == 0:
            # Draw line with tag so it can be deleted later
            self.plot_line(base_left, base_right)
        else:
            # Divide the line into 3 segments
            step_x = (base_right[0] - base_left[0]) / 3
            step_y = (base_right[1] - base_left[1]) / 3

            pt_one  = [base_left[0] + step_x,     base_left[1] + step_y]
            pt_two  = [base_left[0] + 2 * step_x, base_left[1] + 2 * step_y]

            # Calculate peak of outward equilateral triangle
            rotation_angle = math.radians(60)
            peak_x = pt_one[0] + math.cos(rotation_angle) * (pt_two[0] - pt_one[0]) - math.sin(rotation_angle) * (pt_two[1] - pt_one[1])
            peak_y = pt_one[1] + math.sin(rotation_angle) * (pt_two[0] - pt_one[0]) + math.cos(rotation_angle) * (pt_two[1] - pt_one[1])
            pt_peak = [peak_x, peak_y]

            # Recursively draw 4 line segments
            self.draw_fractal(base_left, pt_one,  order - 1)
            self.draw_fractal(pt_one,  pt_peak,   order - 1)
            self.draw_fractal(pt_peak, pt_two,    order - 1)
            self.draw_fractal(pt_two,  base_right, order - 1)

    def plot_line(self, base_left, base_right):
        self.canvas.create_line(base_left[0], base_left[1], base_right[0], base_right[1], tags="line")

# Run the program
KochSnowflake()