from tkinter import *

class SierpinskiTriangle:
    def __init__(self):
        root = Tk()
        root.title("Sierpinski Triangle")

        self.width = 400
        self.height = 400

        self.canvas = Canvas(root, width=self.width, height=self.height)
        self.canvas.pack()

        control_frame = Frame(root)
        control_frame.pack()

        Label(control_frame, text="Enter an order: ").pack(side=LEFT)
        self.depth_input = StringVar()
        Entry(control_frame, textvariable=self.depth_input, justify=RIGHT).pack(side=LEFT)
        Button(control_frame, text="Display Sierpinski Triangle", command=self.render).pack(side=LEFT)

        root.mainloop()

    def render(self):
        order = int(self.depth_input.get())

        self.canvas.delete("line")

        apex = [self.width / 2, 10]
        base_left = [10, self.height - 10]
        base_right = [self.width - 10, self.height - 10]

        self.draw_fractal(order, apex, base_left, base_right)

    def draw_fractal(self, order, apex, base_left, base_right):
        if order == 0:
            self.plot_line(apex, base_left)
            self.plot_line(base_left, base_right)
            self.plot_line(base_right, apex)
        else:
            mid_left = self.calc_midpoint(apex, base_left)
            mid_bottom = self.calc_midpoint(base_left, base_right)
            mid_right = self.calc_midpoint(base_right, apex)

            self.draw_fractal(order - 1, apex, mid_left, mid_right)
            self.draw_fractal(order - 1, mid_left, base_left, mid_bottom)
            self.draw_fractal(order - 1, mid_right, mid_bottom, base_right)

    def plot_line(self, apex, base_left):
        self.canvas.create_line(apex[0], apex[1], base_left[0], base_left[1], tags="line")

    def calc_midpoint(self, apex, base_left):
        return [(apex[0] + base_left[0]) / 2, (apex[1] + base_left[1]) / 2]

SierpinskiTriangle()